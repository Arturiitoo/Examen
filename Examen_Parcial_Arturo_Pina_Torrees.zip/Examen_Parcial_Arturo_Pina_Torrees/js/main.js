/* COMPLETE THIS WITH JS AND AJAX*/

function parseInforXMLAjaxPhpDB (refranero){
    var xmlText;
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {

            document.getElementById("refranero").innerHTML = xmlDoc.getElementsByTagName("refranero")[0].childNodes[0].nodeValue;
        }
    };
    xhttp.open("GET", "main.php?examen"+refranero, true);
    xhttp.send();
}
