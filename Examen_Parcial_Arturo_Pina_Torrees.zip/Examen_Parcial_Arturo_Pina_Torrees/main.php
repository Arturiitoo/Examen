<?php 
/* COMPLETE THIS FILE WITH PHP */
if (isset($_GET['refranero'])){
    
    $conn=$_GET['refranero'];
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "DB.sql";
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT sentence FROM refranero WHERE sentence LIKE ‘$_GET[refranero]%’";
    $result = $conn->query($sql);
    if( $result->num_rows > 0){
        while($row = $result -> fetch_assoc()){
            echo $row['refranero'];
            }

}else{
    echo "NONE";
}
    $conn->close();

}

?>